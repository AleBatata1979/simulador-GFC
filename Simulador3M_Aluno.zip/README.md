# Simulador 3M - App do Aluno

Aplicativo em Streamlit para envio e correção de DRE e indicadores.